var oFSO =  new ActiveXObject("Scripting.FileSystemObject")

var oFo = oFSO.CreateTextFile("c:\\testfile1.txt", true, true);

var x = new ActiveXObject("Msxml2.DOMDocument");
x.async = false;
x.validateOnParse = true;
var sFile;
var sFilename;
var sFoldername;
var queue = new Array();

queue[queue.length] = oFSO.GetFolder(".");

var counter = 0;

while(counter < queue.length)
{
  var folder = queue[counter];
  for (var enumtor = new Enumerator(folder.Subfolders) ; !enumtor.atEnd(); enumtor.moveNext())
  {
    try
    {
      queue[queue.length] = enumtor.item();
    }
    catch(e) {}
  }
  for (enumtor = new Enumerator(folder.Files) ; !enumtor.atEnd(); enumtor.moveNext())
  {
    try
    {
		sFile = enumtor.item().Path;
		sFilename = enumtor.item().name;
		sFoldername = folder.name;
		var is_XML=sFile.indexOf('.xml');
		if (is_XML>0)
		{
			x.load(sFile);
			if (x.parseError.errorCode != 0) 
			   {
				var str;
				str = "";
				str = sFoldername + " - " + sFilename + "\n[Reason]=" + x.parseError.reason + "[Text]=" + x.parseError.srcText.substring(x.parseError.linepos-1) + "\n";
				oFo.WriteLine(str); 
			   }
		}
    }
    catch(e){}
  }
  queue[counter] = null;
  counter++;
}
oFo.close();
WScript.Echo("Validate complete, please go to c:\\testfile.txt and fix the errors!");