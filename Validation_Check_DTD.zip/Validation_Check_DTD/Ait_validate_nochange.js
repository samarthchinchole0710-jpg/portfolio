var oFSO =  new ActiveXObject("Scripting.FileSystemObject")

var oFo = oFSO.CreateTextFile("c:\\testfile.txt", true, true);

var x = new ActiveXObject("MSXML2.DOMDocument.4.0");
x.async = false;
x.validateOnParse = true;
var sFile;
var queue = new Array();

queue[queue.length] = oFSO.GetFolder(".");

var counter = 0;

while(counter < queue.length)
{
  var folder = queue[counter];
  for (var enumtor = new Enumerator(folder.Subfolders) ; !enumtor.atEnd(); enumtor.moveNext())
  {
    try
    {
      queue[queue.length] = enumtor.item();
    }
    catch(e) {}
  }
  for (enumtor = new Enumerator(folder.Files) ; !enumtor.atEnd(); enumtor.moveNext())
  {
    try
    {
		sFile = enumtor.item().Path;
		var is_XML=sFile.indexOf('.xml');
		if (is_XML>0)
		{
//			WScript.Echo(sFile);
			x.load(sFile);
			if (x.parseError.errorCode != 0) 
			   {
				var str;
				str = "";
				str = sFile + "\nError" + "\nReason:" + x.parseError.reason + "\nLine:" + x.parseError.line + "\nPosition:" + x.parseError.linepos +"\nText=\n" + x.parseError.srcText.substring(x.parseError.linepos-1);
				oFo.WriteLine(str);
//				WScript.Echo("Error" + "\nReason:" + x.parseError.reason + "\nLine:" + x.parseError.line + "\nPosition:" + x.parseError.linepos +"\nText=\n" + x.parseError.srcText.substring(x.parseError.linepos-1)); 
			   }
//			else
//				oFo.WriteLine(sFile + "\n===NO PARSE ERROR===\n");
//				WScript.Echo(sFile + "\n===NO PARSE ERROR===\n");
//					oFo.WriteLine("===========================================\n");
//				WScript.Echo("===========================================");
		}
    }
    catch(e){}
  }
  queue[counter] = null;
  counter++;
}
oFo.close();
WScript.Echo("Validate complete, please go to c:\\testfile.txt and fix the errors!");