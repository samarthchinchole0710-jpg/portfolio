wscript.exe Ait_copy.js
wscript.exe Ait_validate.js
wscript.exe Ait_del.js
notepad c:\cisco\testfile.txt