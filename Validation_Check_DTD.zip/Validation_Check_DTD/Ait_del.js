var oFSO = new ActiveXObject("Scripting.FileSystemObject");
var folder = oFSO.GetFolder(".");

for (var enumtor = new Enumerator(folder.Subfolders) ; !enumtor.atEnd(); enumtor.moveNext())
{
    try
    {
      var str = enumtor.item();			
	  var oFSO_DEL = new ActiveXObject("Scripting.FileSystemObject");
	  var bookmap = oFSO_DEL.GetFile(str + "\\cisco-bookmap.dtd");
	  var concept = oFSO_DEL.GetFile(str + "\\cisco-concept.dtd");
	  var glossary = oFSO_DEL.GetFile(str + "\\cisco-glossary.dtd");
	  var glossgroup = oFSO_DEL.GetFile(str + "\\cisco-glossgroup.dtd");
	  var map = oFSO_DEL.GetFile(str + "\\cisco-map.dtd");
	  var reference = oFSO_DEL.GetFile(str + "\\cisco-reference.dtd");
	  var task = oFSO_DEL.GetFile(str + "\\cisco-task.dtd");
	  var topic = oFSO_DEL.GetFile(str + "\\cisco-topic.dtd");
	  
	  bookmap.Delete();
	  concept.Delete();
	  glossary.Delete();
	  glossgroup.Delete();
	  map.Delete();
	  reference.Delete();
	  task.Delete();
	  topic.Delete();
    }
    catch(e){}
}