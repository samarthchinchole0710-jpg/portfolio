var oFSO =  new ActiveXObject("Scripting.FileSystemObject");

var folder = oFSO.GetFolder(".");

var bookmap = oFSO.GetFile("cisco-bookmap.dtd");
var concept = oFSO.GetFile("cisco-concept.dtd");
var glossary = oFSO.GetFile("cisco-glossary.dtd");
var glossgroup = oFSO.GetFile("cisco-glossgroup.dtd");
var map = oFSO.GetFile("cisco-map.dtd");
var reference = oFSO.GetFile("cisco-reference.dtd");
var task = oFSO.GetFile("cisco-task.dtd");
var topic = oFSO.GetFile("cisco-topic.dtd");

for (var enumtor = new Enumerator(folder.Subfolders) ; !enumtor.atEnd(); enumtor.moveNext())
  {
    try
    {
      var str = enumtor.item();
	  bookmap.Copy(str + "\\cisco-bookmap.dtd");
	  concept.Copy(str + "\\cisco-concept.dtd");
	  glossary.Copy(str + "\\cisco-glossary.dtd");
	  glossgroup.Copy(str + "\\cisco-glossgroup.dtd");
	  map.Copy(str + "\\cisco-map.dtd");
	  reference.Copy(str + "\\cisco-reference.dtd");
	  task.Copy(str + "\\cisco-task.dtd");
	  topic.Copy(str + "\\cisco-topic.dtd");
    }
    catch(e) {}
  }