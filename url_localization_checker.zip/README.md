# Localized Document URL Checker

A local Streamlit app to compare URLs in a source and alternate localized DOCX, PDF, or PPTX document. It can optionally check HTTP liveness and redirects and export an Excel report.

## Requirements
- Python 3.10 or newer
- Internet access for live URL checks

## Run on macOS / Windows / Linux

1. Extract this ZIP file.
2. Open Terminal / Command Prompt and change directory into the extracted folder.
3. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   python -m streamlit run app.py
   ```

5. Your browser will open a local page (usually `http://localhost:8501`).
6. Upload the source and localized files, click **Analyze documents**, then download the Excel report.

## Notes and limitations
- The app runs locally; uploaded documents are processed by the local Python process.
- Live URL checks contact the URLs you upload. Only check URLs you are permitted to access.
- HTTP 4xx/5xx responses are reported as HTTP errors. Network, DNS, SSL, timeout, or bot-protection errors are reported as unverified rather than definitely broken.
- Redirect chains are collected using HTTP GET requests and Requests' redirect history.
- Matching is conservative: exact URL match after basic normalization. It does not infer that two different localized paths are equivalent.
- PDF text URLs and clickable PDF links are supported. Scanned/image-only PDFs need OCR and are not covered by this starter version.
- Complex Word documents may contain hyperlinks in drawing objects or embedded content not covered by this starter version.
- For large document sets, the URL check can take time because URLs are checked one by one.
