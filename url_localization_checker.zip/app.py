import io
import re
import time
from urllib.parse import urlsplit, urlunsplit, urldefrag

import pandas as pd
import requests
import streamlit as st
from docx import Document
from pptx import Presentation
from pypdf import PdfReader

st.set_page_config(page_title="Localized Document URL Checker", layout="wide")
st.title("Localized Document URL Checker")
st.caption("Compare URLs in source and localized DOCX, PDF, or PPTX files; check HTTP status and redirects.")

URL_RE = re.compile(r"""(?i)\b(?:https?://|www\.)[^\s<>"'\]\[{}|\\^`]+""")

def clean_url(raw):
    raw = (raw or "").strip().rstrip(".,;:!?)")
    if raw.lower().startswith("www."):
        raw = "https://" + raw
    if not raw:
        return ""
    parts = urlsplit(raw)
    if parts.scheme.lower() not in ("http", "https") or not parts.netloc:
        return ""
    # Preserve path/query case; remove fragment because it is not sent to the server.
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), parts.path or "/", parts.query, ""))

def add_text_urls(text, location, found):
    for match in URL_RE.findall(text or ""):
        url = clean_url(match)
        if url:
            found.append({"URL": url, "Location": location, "Found as": match})

def extract_docx(file_bytes, filename):
    found = []
    doc = Document(io.BytesIO(file_bytes))
    for i, p in enumerate(doc.paragraphs, 1):
        add_text_urls(p.text, f"Paragraph {i}", found)
        # Extract clickable hyperlink targets from the underlying Word XML.
        for link in p._p.xpath(".//w:hyperlink"):
            rid = link.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
            if rid and rid in p.part.rels:
                target = p.part.rels[rid].target_ref
                url = clean_url(target)
                if url:
                    found.append({"URL": url, "Location": f"Paragraph {i} (hyperlink)", "Found as": target})
    for ti, table in enumerate(doc.tables, 1):
        for ri, row in enumerate(table.rows, 1):
            for ci, cell in enumerate(row.cells, 1):
                add_text_urls(cell.text, f"Table {ti}, row {ri}, cell {ci}", found)
                for p in cell.paragraphs:
                    for link in p._p.xpath(".//w:hyperlink"):
                        rid = link.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
                        if rid and rid in p.part.rels:
                            target = p.part.rels[rid].target_ref
                            url = clean_url(target)
                            if url:
                                found.append({"URL": url, "Location": f"Table {ti}, row {ri}, cell {ci} (hyperlink)", "Found as": target})
    # Headers and footers
    for si, section in enumerate(doc.sections, 1):
        for kind, part in (("header", section.header), ("footer", section.footer)):
            for pi, p in enumerate(part.paragraphs, 1):
                add_text_urls(p.text, f"Section {si} {kind}, paragraph {pi}", found)
                for link in p._p.xpath(".//w:hyperlink"):
                    rid = link.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
                    if rid and rid in p.part.rels:
                        target = p.part.rels[rid].target_ref
                        url = clean_url(target)
                        if url:
                            found.append({"URL": url, "Location": f"Section {si} {kind} (hyperlink)", "Found as": target})
    return found

def extract_pptx(file_bytes, filename):
    found = []
    prs = Presentation(io.BytesIO(file_bytes))
    for si, slide in enumerate(prs.slides, 1):
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False):
                add_text_urls(shape.text, f"Slide {si}", found)
                for p in shape.text_frame.paragraphs:
                    for run in p.runs:
                        try:
                            target = run.hyperlink.address
                        except Exception:
                            target = None
                        url = clean_url(target) if target else ""
                        if url:
                            found.append({"URL": url, "Location": f"Slide {si} (hyperlink)", "Found as": target})
            if getattr(shape, "has_table", False):
                for ri, row in enumerate(shape.table.rows, 1):
                    for ci, cell in enumerate(row.cells, 1):
                        add_text_urls(cell.text, f"Slide {si}, table row {ri}, cell {ci}", found)
    return found

def extract_pdf(file_bytes, filename):
    found = []
    reader = PdfReader(io.BytesIO(file_bytes))
    for pi, page in enumerate(reader.pages, 1):
        add_text_urls(page.extract_text() or "", f"Page {pi}", found)
        try:
            for annot in (page.get("/Annots") or []):
                obj = annot.get_object()
                action = obj.get("/A")
                if action:
                    target = action.get("/URI")
                    url = clean_url(str(target)) if target else ""
                    if url:
                        found.append({"URL": url, "Location": f"Page {pi} (clickable link)", "Found as": str(target)})
        except Exception:
            pass
    return found

def extract_urls(upload):
    data = upload.getvalue()
    name = upload.name.lower()
    if name.endswith(".docx"):
        rows = extract_docx(data, upload.name)
    elif name.endswith(".pptx"):
        rows = extract_pptx(data, upload.name)
    elif name.endswith(".pdf"):
        rows = extract_pdf(data, upload.name)
    else:
        raise ValueError("Unsupported file type. Use DOCX, PDF, or PPTX.")
    df = pd.DataFrame(rows, columns=["URL", "Location", "Found as"])
    if not df.empty:
        df = df.drop_duplicates(subset=["URL", "Location", "Found as"])
    return df

def norm_for_match(url):
    # Matching is intentionally conservative: hostname case and fragments are normalized,
    # but path/query differences remain visible as potential localization changes.
    try:
        parts = urlsplit(url)
        return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), parts.path.rstrip("/") or "/", parts.query, ""))
    except Exception:
        return url

def check_url(url, timeout=12):
    headers = {"User-Agent": "Mozilla/5.0 (compatible; DocumentURLChecker/1.0)"}
    try:
        # GET is more reliable than HEAD because some servers reject HEAD requests.
        response = requests.get(url, allow_redirects=True, timeout=timeout, headers=headers, stream=True)
        history = response.history
        chain = " -> ".join([f"{r.status_code} {r.url}" for r in history] + [f"{response.status_code} {response.url}"])
        result = {
            "HTTP Status": response.status_code,
            "Liveness": "Reachable" if response.status_code < 400 else "HTTP error",
            "Redirected": "Yes" if history else "No",
            "Redirect Chain": chain,
            "Final URL": response.url,
            "Check Error": ""
        }
        response.close()
        return result
    except requests.exceptions.TooManyRedirects as e:
        return {"HTTP Status": "", "Liveness": "Redirect loop / too many redirects", "Redirected": "Unknown", "Redirect Chain": "", "Final URL": "", "Check Error": str(e)}
    except requests.exceptions.Timeout as e:
        return {"HTTP Status": "", "Liveness": "Timeout / unverified", "Redirected": "Unknown", "Redirect Chain": "", "Final URL": "", "Check Error": str(e)}
    except requests.exceptions.RequestException as e:
        return {"HTTP Status": "", "Liveness": "Connection/DNS/SSL error - unverified", "Redirected": "Unknown", "Redirect Chain": "", "Final URL": "", "Check Error": str(e)}

def make_report(source_df, localized_df, do_live, timeout):
    source_urls = set(source_df["URL"]) if not source_df.empty else set()
    local_urls = set(localized_df["URL"]) if not localized_df.empty else set()
    local_norm = {norm_for_match(u): u for u in local_urls}
    source_norm = {norm_for_match(u): u for u in source_urls}
    all_urls = sorted(source_urls | local_urls)
    live = {}
    if do_live:
        progress = st.progress(0, text="Checking URL liveness and redirects...")
        for i, url in enumerate(all_urls):
            live[url] = check_url(url, timeout)
            progress.progress((i + 1) / max(len(all_urls), 1), text=f"Checking URL {i+1} of {len(all_urls)}")
        progress.empty()

    rows = []
    for url in sorted(source_urls):
        match_url = local_norm.get(norm_for_match(url))
        if match_url:
            match_status = "Exact match" if match_url == url else "Match after normalization"
            localized_value = match_url
        else:
            localized_value = ""
            match_status = "Missing from localized document"
        row = {
            "Source URL": url,
            "Localized URL": localized_value,
            "URL Match": match_status,
            "Source Occurrences": int((source_df["URL"] == url).sum()),
            "Localized Occurrences": int((localized_df["URL"] == localized_value).sum()) if localized_value else 0,
            "Source Location(s)": "; ".join(source_df.loc[source_df["URL"] == url, "Location"].astype(str).unique()),
            "Localized Location(s)": "; ".join(localized_df.loc[localized_df["URL"] == localized_value, "Location"].astype(str).unique()) if localized_value else ""
        }
        if do_live:
            sr = live.get(url, {})
            lr = live.get(localized_value, {}) if localized_value else {}
            for prefix, data in (("Source", sr), ("Localized", lr)):
                row[f"{prefix} HTTP Status"] = data.get("HTTP Status", "")
                row[f"{prefix} Liveness"] = data.get("Liveness", "")
                row[f"{prefix} Redirected"] = data.get("Redirected", "")
                row[f"{prefix} Redirect Chain"] = data.get("Redirect Chain", "")
                row[f"{prefix} Final URL"] = data.get("Final URL", "")
                row[f"{prefix} Check Error"] = data.get("Check Error", "")
        rows.append(row)

    for url in sorted(local_urls - set(local_norm.get(norm_for_match(u), "") for u in source_urls)):
        # Any localized URL without a matching source URL is listed as an additional URL.
        if norm_for_match(url) not in source_norm:
            row = {
                "Source URL": "",
                "Localized URL": url,
                "URL Match": "Additional URL in localized document",
                "Source Occurrences": 0,
                "Localized Occurrences": int((localized_df["URL"] == url).sum()),
                "Source Location(s)": "",
                "Localized Location(s)": "; ".join(localized_df.loc[localized_df["URL"] == url, "Location"].astype(str).unique())
            }
            if do_live:
                data = live.get(url, {})
                for prefix in ("Source", "Localized"):
                    use = data if prefix == "Localized" else {}
                    row[f"{prefix} HTTP Status"] = use.get("HTTP Status", "")
                    row[f"{prefix} Liveness"] = use.get("Liveness", "")
                    row[f"{prefix} Redirected"] = use.get("Redirected", "")
                    row[f"{prefix} Redirect Chain"] = use.get("Redirect Chain", "")
                    row[f"{prefix} Final URL"] = use.get("Final URL", "")
                    row[f"{prefix} Check Error"] = use.get("Check Error", "")
            rows.append(row)

    report = pd.DataFrame(rows)
    return report, live

with st.sidebar:
    st.header("Settings")
    run_live = st.checkbox("Check URL liveness and redirects", value=True)
    timeout = st.slider("Timeout per URL (seconds)", min_value=3, max_value=30, value=12)
    st.caption("URL checks need internet access. Corporate firewalls, authentication, bot protection, and rate limits may prevent verification.")

c1, c2 = st.columns(2)
with c1:
    source_file = st.file_uploader("1. Source document", type=["docx", "pdf", "pptx"], key="source")
with c2:
    localized_file = st.file_uploader("2. Alternate localized document", type=["docx", "pdf", "pptx"], key="localized")

if st.button("Analyze documents", type="primary", disabled=not (source_file and localized_file)):
    try:
        with st.spinner("Extracting URLs from documents..."):
            source_df = extract_urls(source_file)
            localized_df = extract_urls(localized_file)
        report, live = make_report(source_df, localized_df, run_live, timeout)
        st.session_state["report"] = report
        st.session_state["source_urls"] = source_df
        st.session_state["localized_urls"] = localized_df
        st.session_state["live"] = live
        st.success("Analysis completed.")
    except Exception as exc:
        st.error(f"Could not analyze these files: {exc}")

if "report" in st.session_state:
    report = st.session_state["report"]
    source_df = st.session_state["source_urls"]
    localized_df = st.session_state["localized_urls"]
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Source URLs", source_df["URL"].nunique() if not source_df.empty else 0)
    m2.metric("Localized URLs", localized_df["URL"].nunique() if not localized_df.empty else 0)
    m3.metric("Missing from localized", int((report["URL Match"] == "Missing from localized document").sum()) if not report.empty else 0)
    m4.metric("Additional localized URLs", int((report["URL Match"] == "Additional URL in localized document").sum()) if not report.empty else 0)

    st.subheader("Comparison report")
    st.dataframe(report, use_container_width=True, hide_index=True)
    st.subheader("Extracted URLs")
    tab1, tab2 = st.tabs(["Source document", "Localized document"])
    with tab1:
        st.dataframe(source_df, use_container_width=True, hide_index=True)
    with tab2:
        st.dataframe(localized_df, use_container_width=True, hide_index=True)

    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        report.to_excel(writer, index=False, sheet_name="Comparison")
        source_df.to_excel(writer, index=False, sheet_name="Source URLs")
        localized_df.to_excel(writer, index=False, sheet_name="Localized URLs")
    st.download_button(
        "Download Excel report",
        data=output.getvalue(),
        file_name="url_localization_report.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    st.info("Matching is conservative and exact after basic normalization. Different localized paths are flagged as missing/additional rather than guessed as equivalents. Scanned PDFs may require OCR, which this starter version does not include.")
else:
    st.markdown("""
    **How to use**
    1. Select the source document.
    2. Select its alternate localized document.
    3. Click **Analyze documents**.
    4. Review the comparison and download the Excel report.

    Supported inputs: `.docx`, `.pdf`, `.pptx`. Clickable hyperlinks and visible URLs are extracted where supported.
    """)
